package org.example;

public enum TipoOperacao {

    DEBITO, CREDITO

}
